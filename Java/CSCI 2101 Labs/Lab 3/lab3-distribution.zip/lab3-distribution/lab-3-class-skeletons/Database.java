
public class Database {
	
    // instance variables

    
    // default constructor only


    // insertEntry method:
	// insert an Entry into the linked list, maintaining
    // alphabetical order (by last name)
	
    
    // findLastName method:
    // Search for the last name specified by the parameter
    // and print out all entries with that last name.
    // Indicate if no entries with that last name are found.
	

    // searchAgeRange method:
    // Given a low age and high age specified by the parameters,
    // print out all entries whose ages are between the low age
    // and high age, inclusive. Indicate if no entries with in
    // that range are found.
		
	
    // printStudents method:
    // Print out all the entries that are students.  Indicate if
    // there are no students.

	
	// print method:
    // Print out all the entries in the database, one to a line.
	
}
