
public class Entry {

    // instance variables

    
	// default constructor
    
    // constructor with parameters specifying
    // the data in the Entry (except for "next")


    // getters and setters


    // toString method:
    // Returns a string describing the Entry's data
    // in the format indicated in the sample output
    // in the lab handout.


}
